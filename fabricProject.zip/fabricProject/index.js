// Initialize a 500 by 500 canvas
const initCanvas = (id) => {
    return new fabric.Canvas(id, {
        width: 888,
        height: 500,
        selection: false
    });
}

// Clears everything but the background image
const clearCanvas = (canvas, state) => {
    state.val = canvas.toSVG()
    console.log(state.val)
    canvas.getObjects().forEach((o) => {
        if (o !== canvas.backgroundImage) {
            canvas.remove(o)
        }
    });
}

// Restore the canvas from the previous clear
const restoreCanvas = (canvas, state) => {

    // If a previous state exists, restore it to the canvas
    if (state.val) {
        fabric.loadSVGFromString(state.val, objects => {
            console.log(objects)
            objects = objects.filter(o => o['xlink:href'] !== backgroundUrl)
            canvas.add(...objects)
            canvas.requestRenderAll()
        })
    }
} 

// Function that sets background based on an image URL
const setBackground = (url, canvas) => {
    fabric.Image.fromURL(url, (img) => {
        canvas.backgroundImage = img
        canvas.renderAll()
    })
}

// Function that swaps whether which mode is selected
const toggleMode = (mode) => {

    if (mode === modes.pan) {
        if (currentMode === modes.pan) {
            currentMode = ''
        }
        else {
            currentMode = modes.pan

            // Turns off drawing mode
            canvas.isDrawingMode = false;
            canvas.renderAll()
        }
    } else if (mode === modes.drawing) {
        if (currentMode === modes.drawing) {
            currentMode = ''

            // Turn the drawing mode off when it's am empty string
            canvas.isDrawingMode = false;
            canvas.renderAll()
        }
        // Initializes the brush
        else {
            // Changes the brush type
            canvas.freeDrawingBrush = new fabric.CircleBrush(canvas)
            //canvas.freeDrawingBrush = new fabric.SprayBrush(canvas)

            // Changes the color and brush width
            //canvas.freeDrawingBrush.color = 'red'
            canvas.freeDrawingBrush.width = 25

            currentMode = modes.drawing
            canvas.freeDrawingBrush.color = color
            canvas.isDrawingMode = true;
            canvas.renderAll()
        }
    }
    console.log(mode)
}

// Sets the pan event for the canvas
const setPanEvents = (canvas) => {

    // Canvas events being fired (example)
    canvas.on('mouse:move', (event) => {
        // console.log(e)

        // If we are in pan mode, do this while the mouse is moving.
        if (currentMode === modes.pan && mousePressed == true){
            // Set cursor when the object is moving
            canvas.setCursor('grab')
            canvas.renderAll()

            // Mouse down event
            const mouseEvent = event.e;
            const delta = new fabric.Point(mouseEvent.movementX, mouseEvent.movementY)
            canvas.relativePan(delta)
        }
    }) 


    // Keeps track of when you click with your mouse
    canvas.on('mouse:down', (event) => {
        mousePressed = true;

        // If we are on "Pan" mode, set the cursor to grab
        if (currentMode === modes.pan) {
            canvas.setCursor('grab')
            canvas.renderAll()
        }
    })

    // Keeps track of when you release a click with a mouse
    canvas.on('mouse:up', (event) => {
        mousePressed = false;
        canvas.setCursor('default')
        canvas.renderAll()
    })
}

// Function to add Rectangle to the canvas 
const createRect = (canvas) => {
    console.log("Rectangle")

    // Function to get the coordinates for the middle of the canvas
    const canvCenter = canvas.getCenter();

    // Sets the rectangle parameters that we want
    const rect = new fabric.Rect({
        width: 100,
        height: 100,
        fill: color,
        left: canvCenter.left,
        top: canvCenter.top,
        originX: 'center',
        originY: 'center',
        cornerColor: 'white'
    })
    // Adds our rectangle to the canvas
    canvas.add(rect)

    // Renders the canvas
    canvas.renderAll()

    rect.on('selected', () => {
        rect.set('fill', 'white')
        canvas.renderAll()
    })
    rect.on('deselected', () => {
        rect.set('fill', color)
        canvas.renderAll()
    })

}

// Function to add Circle to the canvas
const createCirc = (canvas) => {
    console.log("Circle")

    // Function to get coordinates for the middle of the canvas
    const canvCenter = canvas.getCenter();

    // Sets the circle parameters that we want
    const circle = new fabric.Circle({
        radius: 50,
        fill: 'orange',
        left: canvCenter.left,
        top: canvCenter.top,
        originX: 'center',
        originY: 'center',
        cornerColor: 'white'
    })
    // Adds our circle to the canvas
    canvas.add(circle)
    
    // Renders the canvas
    canvas.requestRenderAll()

    // When the object is selected
    circle.on('selected', () => {
        circle.set('stroke', 'white'),
        circle.set('strokeWidth', 2),
        canvas.requestRenderAll()
    })

    // When the object is deselected
    circle.on('deselected', () => {
        circle.set('stroke', 'white'),
        circle.set('strokeWidth', 0),
        canvas.requestRenderAll()
    })

}

// TODO: Fix the restore properties being shifted
const addText = (canvas) => {
    console.log("Text")

    const canvCenter = canvas.getCenter();

    // Load text and creates the properties of the text box
    var textbox = new fabric.Textbox('Text', {
        left: 50,
        top: 50,
        width: 150,
        fontSize: 20
      });

    // Adds the defined textbox into the canvas  
    canvas.add(textbox).setActiveObject(textbox);

    // Adds the font
    fonts.unshift('Times New Roman');

    // Populate the fontFamily select
    /*
    var select = document.getElementById("font-family");

    fonts.forEach(function(font) {
        var option = document.createElement('option');
        option.innerHTML = font;
        option.value = font;
        select.appendChild(option);
    });
    */
}

const addPug = (canvas) => {
    fabric.Object.prototype.transparentCorners = false;
    var radius = 300;

    fabric.Image.fromURL('https://cdn.shopify.com/s/files/1/1061/1924/products/The_Sun_Emoji_1024x1024.png', function(img) {
    img.scale(0.5).set({
        left: 100,
        top: 100,
        angle: -15,
        clipPath: new fabric.Circle({
        radius: radius,
        originX: 'center',
        originY: 'center',
        }),
    });

    (function animate() {
        fabric.util.animate({
        startValue: Math.round(radius) === 50 ? 50 : 300,
        endValue: Math.round(radius) === 50 ? 300 : 50,
        duration: 1000,
        onChange: function(value) {
            radius = value;
            img.clipPath.set('radius', value);
            img.set('dirty', true);
            canvas.renderAll();
        },
        onComplete: animate
        });
    })();

    canvas.add(img).setActiveObject(img);
    });
}

// Function to add image to canvas (From Image URL)
const addImage = (canvas) => {
    fabric.Image.fromURL('https://castus-vod-dev.s3.amazonaws.com/outputs/61941fa7a115510009add6c7/Default/Thumbnails/out_003.png', (oImg) => {
    // Scales the image to be smaller
    // TODO: Make it scale depending on the size    
    oImg.scale(0.20).set('flipX', false);
        canvas.add(oImg);
    });
    canvas.renderAll()
}

// Font companion function
const loadAndUse = (font) => {
    var myfont = new FontFaceObserver(font)
    myfont.load()
      .then(function() {
        // when font is loaded, use it.
        canvas.getActiveObject().set("fontFamily", font);
        canvas.requestRenderAll();
      }).catch(function(e) {
        console.log(e)
        alert('font loading failed ' + font);
      });
}

// Function to group all objects on screen
const groupObjects = (canvas, group, shouldGroup) => {
    if(shouldGroup == true){
        const objects = canvas.getObjects()
        // Groups the objects
        group.val = new fabric.Group(objects, {cornerColor: 'white'})
        
        // Erases canvas
        clearCanvas(canvas, svgState)

        // Adds the group back to the canvas
        canvas.add(group.val)
        canvas.requestRenderAll()
    }
    else{

        // Destroys the state
        group.val.destroy()

        // Returns array of the objects
        const oldGroup = group.val.getObjects()
        
        // Removes the group
        canvas.remove(group.val)

        // Spread operator (...) spread
        canvas.add(...oldGroup)

        // Set the group parameter to null since we no longer have a group
        group.val = null

        canvas.requestRenderAll()
    }
}

// Sets up the color listener in the application
const setColorListener = () => {
    // Gets the color picker we are talking about
    const picker = document.getElementById('colorPicker')

    // Add event listener to picker so we know when colors update
    picker.addEventListener('change', (event) => {
        console.log(event.target.value)
        color = event.target.value
        console.log(color)
        canvas.freeDrawingBrush.color = color
        canvas.renderAll()
    })
}

// Initializes the Canvas based on the function parameters
const canvas = initCanvas('canvas');

// Current mode the program is in
let currentMode;

// Global variable that determines the state of the mouse 
let mousePressed = false;

// Sets the default color picker color
let color = '#000000'

// Variable for selected object 
let selectedObject = {}

// Group state
const group = {};

// List all modes you want
const modes = {
    pan: 'pan',
    drawing: 'drawing'
}

// State of our restoration
const svgState = {}

// Fonts to load into the program
var fonts = ["Pacifico", "VT323", "Quicksand", "Inconsolata"];

// Sets the URL for the background
const backgroundUrl = 'https://cdn.pixabay.com/photo/2016/07/09/07/48/blue-sky-1505848_960_720.jpg'

// Sets the background with an image URL
setBackground(backgroundUrl, canvas);

// Sets the Pan event
setPanEvents(canvas)

// Sets the color listener
setColorListener()